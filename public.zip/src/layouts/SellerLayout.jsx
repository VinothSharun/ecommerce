const SellerLayout = () => {
  return (
    <div>
      Seller Layout
    </div>
  );
};

export default SellerLayout;
