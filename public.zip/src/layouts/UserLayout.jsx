export default function UserLayout() {
  return (
    <div>
      <h1>User Layout</h1>
    </div>
  );
}
