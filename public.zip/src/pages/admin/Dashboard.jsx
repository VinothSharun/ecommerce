const Dashboard = () => {
  return (
    <div>
      Admin Dashboard
    </div>
  );
};

export default Dashboard;
