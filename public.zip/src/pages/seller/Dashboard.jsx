const Dashboard = () => {
  return (
    <div>
      Seller Dashboard
    </div>
  );
};

export default Dashboard;
