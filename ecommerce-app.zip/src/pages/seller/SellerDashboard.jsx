const SellerDashboard = () => {
  return (
    <div className="dashboard">
      
      
    </div>
  );
};

export default SellerDashboard;
