const AdminDashboard = () => {
  return (
    <div className="dashboard">
      
    </div>
  );
};

export default AdminDashboard;
