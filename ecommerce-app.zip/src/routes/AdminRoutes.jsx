// No longer needed. Admin routes are now nested in AppRoutes.jsx
